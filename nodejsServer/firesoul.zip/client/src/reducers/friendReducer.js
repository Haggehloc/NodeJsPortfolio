import {
  GET_FRIENDS,
  ADD_FRIENDS,
  GET_FRIEND_REQUESTS
} from "../actions/types";

const initialState = {
friends: null;
};

export default function(state = initialState, action) {
  switch (action.type) {
    case GET_FRIENDS:
      return {
        ...state,
        friends: action.friends
      };

    default:
      return state;
  }
}
