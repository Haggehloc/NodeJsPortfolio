import React, { Component } from "react";
import { connect } from "react-redux";
import { Link, withRouter } from "react-router-dom";
import PropTypes from "prop-types";
/**
 * Friends
 */
export class Friends extends Component {
  render() {
    return <div>MY COMPONENT</div>;
  }
}

Friends.propTypes = {
  profile: PropTypes.object.isRequired,
  errors: PropTypes.object.isRequired
};

export default Friends;
