import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { deleteGame } from "../../actions/profileActions";

class Games extends React.Component {
  onDeleteClick(id) {
    this.props.deleteGame(id);
  }

  render() {
    const games = this.props.games.map(game => (
      <tr>
        <td>{game.name}</td>
        <td>{game.handle}</td>
        <td>{game.platform}</td>
        <td>{game.rank}</td>
        <td>
          <button
            type="button"
            onClick={this.onDeleteClick.bind(this, game._id)}
            className="btn btn-danger"
          >
            Delete
          </button>
        </td>
      </tr>
    ));

    return (
      <div>
        <h4 className="mb-4">Games</h4>
        <table className="table">
          <tr>
            <th>Name</th>
            <th>Handle</th>
            <th>Rank</th>
            <th>Platform</th>
            <th />
          </tr>
          {games}
        </table>
      </div>
    );
  }
}

Games.propTypes = {
  deleteExperience: PropTypes.func.isRequired
};

export default connect(
  null,
  { deleteGame }
)(Games);
