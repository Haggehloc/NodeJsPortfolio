import React from "react";
import { Link } from "react-router-dom";

const ProfileActions = () => {
  return (
    <div className="btn-group mb-4" role="group">
      <Link to="/edit-profile" className="btn btn-light">
        <i className="fas fa-user-circle text-info mr-1" /> Edit Profile
      </Link>
      <Link to="/add-games" className="btn btn-light">
        <i className="fas fa-gamepad text-info mr-1" />
        Add Games
      </Link>
      <Link to="/friends" className="btn btn-light">
        <i className="fas fa-user text-info mr-1" />
        Friends
      </Link>
      <Link to="/add-friends" className="btn btn-light">
        <i className="fas fa-user-plus text-info mr-1" />
        Add Friends
      </Link>
      <Link to="/add-favorites" className="btn btn-light">
        <i className="fas fa-hand-spock text-info mr-1" />
        Add favorites
      </Link>
    </div>
  );
};
export default ProfileActions;
