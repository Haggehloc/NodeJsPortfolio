module.exports = {
  mongoURI:
  'mongodb+srv://admin:2nFWjpcHWVj4PMrR@socialcluster-a8ly8.mongodb.net/test?retryWrites=true',

  secretOrKey: "5gP=je&{yt}2#@WUti'Ve@u>O:Jz/8+;37&v7/=y|1!dmm[#}2jjrs'mF<:[%]("
};
